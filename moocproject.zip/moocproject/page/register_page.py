#coding = utf-8
"""获取页面元素"""
from selenium import webdriver
from base.find_element import FindElement
class RegisterPage(object):
    def __init__(self,driver):
        self.find_e = FindElement(driver)
    #获取邮箱
    def get_email_element(self):
        self.find_e.get_element("user_email")
        # print(self.find_e.get_element('user_email'))
    #
    def get_email_error(self):
        self.find_e.get_element("email_error")

    def get_name_element(self):
        self.find_e.get_element("user_name")

    def get_name_error(self):
        self.find_e.get_element("name_error")

    def get_password_elenemt(self):
        self.find_e.get_element("password")

    def get_password_error(self):
        self.find_e.get_element("password_error")

    def get_code_text(self):
        self.find_e.get_element("code_text")

    def get_code_error(self):
        self.find_e.get_element('code_error')

    def get_button(self):
        self.find_e.get_element('user_button')

