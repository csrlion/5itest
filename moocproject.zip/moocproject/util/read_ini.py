import configparser

# class ReadIni():
#     def __init__(self,file_name = None,node= None):
#         if file_name ==None:
#             file_name = "F:/PycharmProjects/moocproject/config/LocalElement.ini"
#         if node == None:
#             self.node = "RegisterElement"
#         else:
#             self.node=node
#         self.cf = self.load_ini(file_name)

    # def load_ini(self,file_name):
    #     cf = configparser.ConfigParser()
    #     cf.read(file_name)
    #     return cf
    # def get_value(self,key):
    #     date = self.cf.get(self.node,key)
    #     return date

# if __name__ =='__main__':
#     read_init = ReadIni()
#     print(read_init.get_value('useremail'))

# cf = configparser.ConfigParser()
# cf.read(r"F:\PycharmProjects\moocproject\config\LocalElement.ini")
# print(cf.get('RegisterElement','user_email'))


class ReadIni(object):

    def __init__(self,file_name=None,node = None):
        if file_name == None:
            file_name="F:/PycharmProjects/moocproject/config/LocalElement.ini"
        else:
            self.file_name=file_name
        if node==None:
            self.node = "RegisterElement"
        else:
            self.node=node

        self.cf = self.load_ini(file_name)
    #读取文件
    def load_ini(self,file_name):
        cf = configparser.ConfigParser()
        cf.read(file_name)
        return cf
    #获取值
    def get_value(self,key):
        data = self.cf.get(self.node,key)
        return data

if __name__ == '__main__':
    read_ini = ReadIni()
    print(read_ini.get_value("user_email"))