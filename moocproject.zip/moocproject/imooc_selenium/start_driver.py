from PIL import Image
from selenium import webdriver
#验证页面是否正确,根据title判断
# driver = webdriver.Firefox()
from imooc_selenium.ShowapiRequest import ShowapiRequest

driver = webdriver.Chrome()
driver.get("http://www.5itest.cn/register")
driver.maximize_window()
# driver.get("http://http://www.5itest.cn/register")
# sleep(5)
# EC.title_contains("注册")     #使用title判断页面是否正确
#判断页面是否正确：通过查找元素看是否能查找到相关元素
# locator = (By.CLASS_NAME,"controls")
# WebDriverWait(driver,10).until(EC.visibility_of_element_located(locator))


#判断自己输入邮箱是否与真实输入相同
# email_element = driver.find_element_by_id("register_email")
# email_element.get_attribute("placeholder")
# print(email_element.get_attribute("placeholder"))
# email_element.send_keys("131877@.com")
# email_element.get_attribute("value")
# print(email_element.get_attribute("value"))

#自动生成用户名使用random.sample（）
# for i in range(5):
#     username = ''.join(random.sample('abcdefghijk123456',5))+"@163.com"
#     print(username)
#
def cut_image():
    driver.save_screenshot("imooc.png")  # 保存整个页面图片
    element_code = driver.find_element_by_id("getcode_num")  # 根据id找到验证码图片
    print(element_code.location)  # 获取验证码图片的顶点坐标
    left = element_code.location['x']
    top = element_code.location['y']
    right = element_code.size['width'] + left
    height = element_code.size['height'] + top
    im = Image.open("imooc.png")
    img = im.crop((left, top, right, height))  # 剪切图片
    img.save("imooc1.png")

def image_yanzheng():
    cut_image()
    # im = Image.size
    r = ShowapiRequest("http://route.showapi.com/184-4","81705","b7a25ac069ef4bbaa4f02985225aead3" )
    r.addBodyPara("typeId", "35")
    r.addBodyPara("convert_to_jpg", "0")
    r.addBodyPara("needMorePrecise", "0")
    r.addFilePara("image", r"imooc1.png") #文件上传时设置
    res = r.post()
    text = res.json()['showapi_res_body']['Result']
    print(text) # 返回信息
    return text

#定位元素方法
driver.find_element_by_id("register_email").send_keys("13187761676@163.com")
user_name_parents = driver.find_elements_by_class_name("controls")[1]
# print(user_name_parents)
user_name = user_name_parents.find_element_by_class_name("form-control").send_keys("892763")
driver.find_element_by_xpath("//*[@id='register_password']").send_keys("11111")
driver.find_element_by_name("captcha_code").send_keys(image_yanzheng())
driver.find_element_by_id('register-btn').click()


driver.close()


