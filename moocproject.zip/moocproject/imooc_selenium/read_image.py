from imooc_selenium.ShowapiRequest import ShowapiRequest

#搞定验证码：方法保存页面，裁剪下验证码区使用pillow库
# img = Image.open('imooc1.png')
# text = pytesseract.image_to_string(img)

#使用接口搞定验证码
r = ShowapiRequest("http://route.showapi.com/184-4","81705","b7a25ac069ef4bbaa4f02985225aead3" )
r.addBodyPara("typeId", "35")
r.addBodyPara("convert_to_jpg", "0")
r.addBodyPara("needMorePrecise", "0")
r.addFilePara("image", r"imooc1.png") #文件上传时设置
res = r.post()
text = res.json()['showapi_res_body']['Result']
print(text) # 返回信息