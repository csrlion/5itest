#code=utf-8
import sys
sys.path.append('F:\PycharmProjects\moocproject')
from time import sleep
import random
from PIL import Image
from selenium import webdriver
from imooc_selenium.ShowapiRequest import ShowapiRequest
from base.find_element import FindElement


class RegisterFunction(object):
    def __init__(self,url,i):
        self.driver = self.get_driver(url,i)

    def get_driver(self,url,i):
        if i ==1:
            driver = webdriver.Chrome()
        elif i ==2:
            driver = webdriver.Firefox()
        else:
            driver = webdriver.Ie()

        driver.get(url)
        driver.maximize_window()
        return driver

    #输入用户信息
    def send_user_info(self,key,data):
        self.get_user_element(key).send_keys(data)


    #获取element
    def get_user_element(self,key):
        find_element = FindElement(self.driver)
        user_element = find_element.get_element(key)
        return user_element

    # 获取图片解析图片
    def get_code_image(self,file_name):
        self.driver.save_screenshot(file_name)
        element = self.get_user_element('code_image')
        # element.location
        left = element.location['x']
        top = element.location['y']
        # element.size
        right = element.size['width'] + left
        height = element.size['height'] + top
        im = Image.open(file_name)
        image = im.crop((left, top, right, height))
        image.save(file_name)

    # 获取验证码
    def get_image(self,file_name):
        self.get_code_image(file_name)
        r = ShowapiRequest("http://route.showapi.com/184-4", "81705", "b7a25ac069ef4bbaa4f02985225aead3")
        r.addBodyPara("typeId", "35")
        r.addBodyPara("convert_to_jpg", "0")
        r.addBodyPara("needMorePrecise", "0")
        r.addFilePara("image", file_name)  # 文件上传时设置
        res = r.post()
        text = res.json()['showapi_res_body']['Result']
        return text  # 返回信息

    # 随机数生成
    def get_range_user(self):
        name_info = ''.join(random.sample("1234567890abcdefghijklmn", 8))
        return name_info

    def main(self,i):
        user_name_info = self.get_range_user()
        user_email = user_name_info + "@163.com"
        file_name= "F:/PycharmProjects/moocproject/image/mooc.png"
        #code_text = self.get_image(file_name)
        self.send_user_info('user_email',user_email)
        self.send_user_info('user_name',user_name_info)
        self.send_user_info('password','111111')
        self.send_user_info('code_text','11111')
        self.get_user_element('user_button').click()
        code_error = self.get_user_element('code_error')
        if code_error ==None:
            print("验证码通过")
        else:
            if i ==1:
                file_num = ''.join(random.sample("1234567890", 2))+'Chrome'
            elif i ==2:
                file_num = ''.join(random.sample("1234567890", 2)) + 'Firefox'
            else:
                file_num = ''.join(random.sample("1234567890", 2)) + 'IE'
            self.driver.save_screenshot(r'F:\PycharmProjects\moocproject\image\{}codeerror.png'.format(file_num))
        sleep(5)
        self.driver.close()

if __name__ == '__main__':
    for i in range(3):
        register = RegisterFunction("http://www.5itest.cn/register",i)
        register.main(i)



# driver = webdriver.Chrome()
# url = r"http://www.5itest.cn/register"
# driver.get(url)