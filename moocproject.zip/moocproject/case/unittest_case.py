#coding=utf-8

"""
unittest使用定义函数必须以test开头
必须有前置条件和后置条件
前置条件：setUp
后置条件：tearDown

"""
import unittest
class FirstCase(unittest.TestCase):
    def setUp(self):
        print("这个是case的前置条件")
    def tearDown(self):
        print("这个是case的后置条件")
    def testfirst01(self):
        print("第一条case")
    def testfirst02(self):
        print("第二条case")

if __name__ == '__main__':
    unittest.main()