#coding = utf-8

"""
    po模型
    分离测试对象（元素对象）和测试脚本（用例脚本）
    主要用于输入case（用例），操作后面的方法和输入用例
    login方法主要是用于操作流程定义在handle中
    case层需要输入用户名邮箱密码等信息
    handle输入用户名邮箱等操作
"""
import sys
sys.path.append(r'F:\PycharmProjects\moocproject')
from business.registerbusiness import RegisterBusiness
from selenium import webdriver
import unittest
class FirstCase(unittest.TestCase):

    def setUp(self):
        self.driver = webdriver.Chrome()
        self.driver.get(r"http://www.5itest.cn/register")
        self.login = RegisterBusiness(self.driver)
    def tearDown(self):
        self.driver.close()
        print("这个是case的后置条件")
    def test_login_email_error(self):
        email_error = self.login.login_email_error('11','user111','11111','test11')
        if email_error ==True:
            print("注册成功了，此条case失败")
    def test_username_error(self):
        name_error = self.login.login_name_error('11','user111','11111','test11')
        if name_error ==True:
            print("注册成功了，此条case失败")

    def test_login_password_error(self):
        password_error =self.login.login_password_error('11','user111','11111','test11')
        if password_error ==True:
            print("注册成功了，此条case失败")

    def test_login_code_error(self):
        code_error =self.login.login_code_error('11','user111','11111','test11')
        if code_error ==True:
            print("注册成功了，此条case失败")

    def test_login_success(self):
        success = self.login.user_base('11','user111','11111','test11')
        if self.login.login_success() ==True:
            print("注册成功了")
"""
def main():
    first =FirstCase()
    first.test_login_code_error()
    first.test_login_email_error()
    first.test_login_password_error()
    first.test_username_error()
    first.test_login_success()
"""


if __name__ == '__main__':
    unittest.main()