#coding = utf-8
"""
    po模型的操作层
    进行数据操作，与fistcase对应
    case中需要输入用户名邮箱等信息
    handle就是对用户名邮箱等输入信息进行操作，操作中需要干的事就是对页面元素进行操作
    这时需要将case和handle进行连接起来，这时需要business层对handle层操作
    对页面元素进行操作封装在business层中将case和handle链接起来操作handle层

"""

from page.register_page import RegisterPage

class RegisterHandle(object):
    def __init__(self,driver):
        self.register_p = RegisterPage(driver)

    # 输入邮箱
    def send_user_email(self,email):
         self.register_p.get_email_element().send_keys(email)

    #输入用户名
    def send_user_name(self,name):
        self.register_p.get_name_element().send_keys(name)

    #输入密码
    def send_user_password(self,password):
        self.register_p.get_password_elenemt().send_keys(password)

    #输入验证码
    def send_user_code(self,code):
        self.register_p.get_code_text().send_keys(code)

    #H获取页面反馈信息
    def get_user_text(self,info,user_info):
        if info == 'email_error':
            text = self.register_p.get_email_error().get_attribute('value')
        elif info =='name_error':
            text = self.register_p.get_name_error().get_attribute('value')
        elif info == 'password_error':
            text = self.register_p.get_password_error().get_attribute('value')
        else:
            text = self.register_p.get_code_text().get_attribute('value')
        return text

    def click_register_button(self):
        self.register_p.get_button().click()

    def get_register_text(self):
        self.register_p.get_button().text
